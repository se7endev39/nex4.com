<template>

    <div class="k1_manage_table">
        <h5 class="title p-2">Helper</h5>

        <div class="info mt-0 m-4">

            <p><strong>Episode API Upload</strong></p>
            <hr>

            <p>Before you upload episode multi or single you should rename video file to the same number of episode
                <br>
                Example: 1.mkv = number 1 episode - 2.mkv = number 2 episode
            </p>
            <br>

            <p><strong>Episode Custom Upload</strong></p>
            <hr>
            <p>Before you upload episode multi or single you should rename video and backdrop <strong>Image</strong> file to the same number of episode </p>

            <br>

            <p><strong>Exernal Link Upload</strong></p>
            <hr>
            <p>The External Link Should End With .mp4/.webm for Movie/Episode & M3u8 for Live Tv</p>
            <br>

            <p><strong>Available & Unavailable </strong></p>
            <hr>
            <p>Movies & Episode the default after upload is Unavailable
                <i class="fa fa-spinner" aria-hidden="true"></i>
            </p>

            <br>

            <p><strong>Breaintree Manage</strong></p>
            <hr>
            <p>After you add the plan from Breaintree dashboard, you will see automatically the plan in setting -> Breaintree manage, you can active it in site or inactive
                <br>
                <strong>Important: </strong> If you update the plan details you should inactive plan and active it again
            </p>

            <br>

        </div>

    </div>

</template>
