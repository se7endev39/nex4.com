
<template>
  <div>
    <div class="col-12 alert-notification" v-if="message === 'confirm_email'">
      <div class="offset-sm-1 offset-lg-1 email-confirmed">
        <div class="row">
          <div class="col-3 col-sm-2 col-lg-1 icon">


            <svg version="1.1" width="100%" class="alert-svg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
             viewBox="0 0 60 60" style="enable-background:new 0 0 60 60;" xml:space="preserve">
        <path style="fill:none;stroke:#DC9628;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:10;" d="M34,12
            V8c0-2.209-1.791-4-4-4s-4,1.791-4,4v4.072"/>
        <path style="fill:#EEAF4B;" d="M16.491,50.638c10.701,1.847,16.658,1.847,27.36,0L53.341,49l0,0c-4.685-4.657-7.317-10.415-7.317-17
            v-9c0.038-6.047-3.957-10.478-7.946-12.301c-4.999-2.285-10.815-2.294-15.806,0.008C18.319,12.53,14.038,16.958,14,23v9
            c0,6.585-2.315,12.343-7,17l0,0L16.491,50.638z"/>
        <path style="fill:#FBD490;" d="M19,25.991c-0.002,0-0.004,0-0.006,0c-0.552-0.004-0.997-0.454-0.994-1.006
            c0.03-4.682,3.752-7.643,5.948-8.654c3.849-1.775,8.594-1.772,12.469-0.002c0.502,0.229,0.723,0.822,0.494,1.325
            c-0.229,0.502-0.822,0.724-1.326,0.493c-3.354-1.533-7.469-1.537-10.799,0c-1.767,0.814-4.762,3.173-4.785,6.85
            C19.997,25.547,19.549,25.991,19,25.991z"/>
        <path style="fill:#DC9628;" d="M21.906,51.46C23.35,54.728,26.508,57,30.183,57c3.676,0,6.834-2.273,8.278-5.543
            C32.533,52.209,27.83,52.21,21.906,51.46z"/>
        <path style="fill:#F2ECBF;" d="M4.095,39.967c-0.256,0-0.512-0.098-0.707-0.293C1.203,37.489,0,34.58,0,31.483
            c0-3.098,1.203-6.006,3.388-8.19c0.391-0.391,1.023-0.391,1.414,0s0.391,1.023,0,1.414C2.995,26.514,2,28.92,2,31.483
            c0,2.563,0.995,4.969,2.802,6.776c0.391,0.391,0.391,1.023,0,1.414C4.606,39.869,4.351,39.967,4.095,39.967z"/>
        <path style="fill:#F2ECBF;" d="M8.305,37.69c-0.256,0-0.512-0.098-0.707-0.293c-3.337-3.337-3.337-8.768,0-12.104
            c0.391-0.391,1.023-0.391,1.414,0s0.391,1.023,0,1.414c-2.558,2.558-2.558,6.719,0,9.276c0.391,0.391,0.391,1.023,0,1.414
            C8.817,37.593,8.561,37.69,8.305,37.69z"/>
        <path style="fill:#F2ECBF;" d="M55.905,39.967c-0.256,0-0.512-0.098-0.707-0.293c-0.391-0.391-0.391-1.023,0-1.414
            C57.005,36.452,58,34.046,58,31.483c0-2.563-0.995-4.97-2.802-6.776c-0.391-0.391-0.391-1.023,0-1.414s1.023-0.391,1.414,0
            C58.797,25.478,60,28.386,60,31.483c0,3.097-1.203,6.006-3.388,8.19C56.417,39.869,56.161,39.967,55.905,39.967z"/>
        <path style="fill:#F2ECBF;" d="M51.695,37.69c-0.256,0-0.512-0.098-0.707-0.293c-0.391-0.391-0.391-1.023,0-1.414
            c2.558-2.558,2.558-6.719,0-9.276c-0.391-0.391-0.391-1.023,0-1.414s1.023-0.391,1.414,0c3.337,3.337,3.337,8.768,0,12.104
            C52.207,37.593,51.951,37.69,51.695,37.69z"/>
        </svg>


          </div>
          <div class="col-7 col-sm-10 col-lg-10 ">

        <h3> Confirm Your Email </h3>
        <p>Please check your email,we send to you confirmation code.
          <br> If you recive confirmation email click to
          <a v-if="show" @click="SEND_MAIL" style="color:#0275d8;">send again</a>
          <a style="color:#0275d8;" v-else>Wait..</a>
        </p>
      </div>
    </div>
      </div>
    </div>

    <div class="col-12 alert-notification" v-if="message.cancel">
      <div class="offset-sm-1 offset-lg-1 email-confirmed">
        <div class="row">
          <div class="col-3 col-sm-2 col-lg-1 icon">


              <svg version="1.1" width="100%" class="alert-svg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
             viewBox="0 0 60 60" style="enable-background:new 0 0 60 60;" xml:space="preserve">
        <path style="fill:none;stroke:#DC9628;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:10;" d="M34,12
            V8c0-2.209-1.791-4-4-4s-4,1.791-4,4v4.072"/>
        <path style="fill:#EEAF4B;" d="M16.491,50.638c10.701,1.847,16.658,1.847,27.36,0L53.341,49l0,0c-4.685-4.657-7.317-10.415-7.317-17
            v-9c0.038-6.047-3.957-10.478-7.946-12.301c-4.999-2.285-10.815-2.294-15.806,0.008C18.319,12.53,14.038,16.958,14,23v9
            c0,6.585-2.315,12.343-7,17l0,0L16.491,50.638z"/>
        <path style="fill:#FBD490;" d="M19,25.991c-0.002,0-0.004,0-0.006,0c-0.552-0.004-0.997-0.454-0.994-1.006
            c0.03-4.682,3.752-7.643,5.948-8.654c3.849-1.775,8.594-1.772,12.469-0.002c0.502,0.229,0.723,0.822,0.494,1.325
            c-0.229,0.502-0.822,0.724-1.326,0.493c-3.354-1.533-7.469-1.537-10.799,0c-1.767,0.814-4.762,3.173-4.785,6.85
            C19.997,25.547,19.549,25.991,19,25.991z"/>
        <path style="fill:#DC9628;" d="M21.906,51.46C23.35,54.728,26.508,57,30.183,57c3.676,0,6.834-2.273,8.278-5.543
            C32.533,52.209,27.83,52.21,21.906,51.46z"/>
        <path style="fill:#F2ECBF;" d="M4.095,39.967c-0.256,0-0.512-0.098-0.707-0.293C1.203,37.489,0,34.58,0,31.483
            c0-3.098,1.203-6.006,3.388-8.19c0.391-0.391,1.023-0.391,1.414,0s0.391,1.023,0,1.414C2.995,26.514,2,28.92,2,31.483
            c0,2.563,0.995,4.969,2.802,6.776c0.391,0.391,0.391,1.023,0,1.414C4.606,39.869,4.351,39.967,4.095,39.967z"/>
        <path style="fill:#F2ECBF;" d="M8.305,37.69c-0.256,0-0.512-0.098-0.707-0.293c-3.337-3.337-3.337-8.768,0-12.104
            c0.391-0.391,1.023-0.391,1.414,0s0.391,1.023,0,1.414c-2.558,2.558-2.558,6.719,0,9.276c0.391,0.391,0.391,1.023,0,1.414
            C8.817,37.593,8.561,37.69,8.305,37.69z"/>
        <path style="fill:#F2ECBF;" d="M55.905,39.967c-0.256,0-0.512-0.098-0.707-0.293c-0.391-0.391-0.391-1.023,0-1.414
            C57.005,36.452,58,34.046,58,31.483c0-2.563-0.995-4.97-2.802-6.776c-0.391-0.391-0.391-1.023,0-1.414s1.023-0.391,1.414,0
            C58.797,25.478,60,28.386,60,31.483c0,3.097-1.203,6.006-3.388,8.19C56.417,39.869,56.161,39.967,55.905,39.967z"/>
        <path style="fill:#F2ECBF;" d="M51.695,37.69c-0.256,0-0.512-0.098-0.707-0.293c-0.391-0.391-0.391-1.023,0-1.414
            c2.558-2.558,2.558-6.719,0-9.276c-0.391-0.391-0.391-1.023,0-1.414s1.023-0.391,1.414,0c3.337,3.337,3.337,8.768,0,12.104
            C52.207,37.593,51.951,37.69,51.695,37.69z"/>
        </svg>


          </div>
          <div class="col-7 col-sm-10 col-lg-10 ">
            <h5>Your membership ends soon. </h5>
            <p class="text-muted">Your last day to stream will be
              <b style="color:#0275d8">{{message.cancel_time}}</b>, If you’ve changed your mind, restart your membership now.</p>
            <div class="btn-group-sm mt-1">
              <button class="btn btn-sm btn-warning ml-2 mt-1" @click="RESUME">RESTART MEMBERSHIP</button>
              <button class="btn btn-sm btn-warning ml-2 mt-1" @click="message.cancel = null">REMIND ME LATER</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  const alertify = require('alertify.js');
  export default {
    name: 'message',
    props: {
      message: null,
    },
    data() {
      return {
        show: true,
      }
    },
    methods: {
      SEND_MAIL() {
        this.show = false;
        axios.get("/api/v1/register/sendactivity").then(response => {
          if (response.data.status === "success") {
            this.show = true;
            alertify.logPosition("top right");
            alertify.success(response.data.message);
          }
        });
      },
      RESUME() {
        this.$store.dispatch("RESUME_MEMBERSHIP");
        this.message.cancel = null;
      }
    }
  }
</script>